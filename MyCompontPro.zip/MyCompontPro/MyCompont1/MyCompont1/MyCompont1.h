//
//  MyCompont1.h
//  MyCompont1
//
//  Created by hle2 on 2020/3/10.
//  Copyright © 2020 hle2. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface MyCompont1 : NSObject

@end
