//
//  MyCompont1.m
//  MyCompont1
//
//  Created by hle2 on 2020/3/10.
//  Copyright © 2020 hle2. All rights reserved.
//

#import "MyCompont1.h"
#import "MGJRouter.h"

@implementation MyCompont1

// 在load方法中自动注册，在主工程中不用写任何代码。
+ (void)load {

    [MGJRouter registerURLPattern:@"WEN://Test1/PushMainVC" toHandler:^(NSDictionary *routerParameters) {
        UIViewController *vc = routerParameters[MGJRouterParameterUserInfo][@"vc"];
        NSString *path = [[NSBundle mainBundle] pathForResource:@"MyCompont1Bundle" ofType:@"bundle"];
        NSAssert([NSBundle bundleWithPath:path], @"not found bundle");
        NSBundle *b =  [NSBundle bundleWithPath:path];
        
        UIStoryboard *ub =  [UIStoryboard storyboardWithName:@"MyCompont1" bundle:b];
        UIViewController *cp1 = [ub instantiateViewControllerWithIdentifier:@"MyCompont1"];
        [vc presentViewController:cp1 animated:YES completion:nil];
    }];
}


@end
