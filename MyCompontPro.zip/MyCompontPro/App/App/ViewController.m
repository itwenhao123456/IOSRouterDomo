//
//  ViewController.m
//  App
//
//  Created by hle2 on 2020/3/10.
//  Copyright © 2020 hle2. All rights reserved.
//

#import "ViewController.h"
#import "MGJRouter.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (IBAction)click:(id)sender {
    [MGJRouter openURL:@"WEN://Test1/PushMainVC" withUserInfo:@{@"vc" : self} completion:nil];
}

@end
