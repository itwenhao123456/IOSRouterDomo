//
//  SceneDelegate.h
//  App
//
//  Created by hle2 on 2020/3/10.
//  Copyright © 2020 hle2. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

